package com.example.oki.akihiro.camp_2016_spring_quiz_application;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {


    //宣言
    TextView Result1,Result2,Result3,Result4,Result5,Result6,Result7;


    //プレイヤーのデータを保存する配列
    int player_data[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);


        //クイズアクティビティからプレイヤーデータを取得する。
        Intent getIntent = getIntent();
        Bundle bundle=getIntent.getExtras();
        player_data = bundle.getIntArray("PlayerData");

        //テキストビューを利用できるようにする。
        Result1 = (TextView)this.findViewById(R.id.Result1);
        Result2 = (TextView)this.findViewById(R.id.Result2);
        Result3 = (TextView)this.findViewById(R.id.Result3);
        Result4 = (TextView)this.findViewById(R.id.Result4);
        Result5 = (TextView)this.findViewById(R.id.Result5);
        Result6 = (TextView)this.findViewById(R.id.Result6);
        Result7 = (TextView)this.findViewById(R.id.Result7);

        //プレイヤーデータに基づいて結果を表示する。
        if(player_data[16]==1)
        {
            Result1.setText("○");
        }
        else
        {
            Result1.setText("×");
        }
        if(player_data[17]==1)
        {
            Result2.setText("○");
        }
        else
        {
            Result2.setText("×");
        }
        if(player_data[18]==1)
        {
            Result3.setText("○");
        }
        else
        {
            Result3.setText("×");
        }
        if(player_data[19]==1)
        {
            Result4.setText("○");
        }
        else
        {
            Result4.setText("×");
        }
        if(player_data[20]==1)
        {
            Result5.setText("○");
        }
        else
        {
            Result5.setText("×");
        }
        if(player_data[21]==1)
        {
            Result6.setText("○");
        }
        else
        {
            Result6.setText("×");
        }
        if(player_data[22]==1)
        {
            Result7.setText("○");
        }
        else
        {
            Result7.setText("×");
        }



    }



    //リザルト画面からタイトルへ遷移させる
    public void onClickReturnTitle(View view) {

        switch (view.getId()){
            case R.id.ReturnTitle:
                //インテントにスタートアクティビティをセットする
                Intent intent = new Intent(this, StartActivity.class);

                //別アクティビティへ移動
                startActivity(intent);
                break;
        }
    }
}
