package com.example.oki.akihiro.camp_2016_spring_quiz_application;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.Random;

public class StartActivity extends AppCompatActivity {


    /*
        プレイヤーデータのセッティング

        0:問題番号　1:1問目の答え　2:2問目の答え 3:3問目の答え 4:4問目の答え 5:5問目の答え 6:6問目の答え 7:7問目の答え
                  8:1問目のプレイヤーの解答　9:2問目の解答 10:3問目の解答 11:4問目の解答 12:5問目の解答 13:6問目の解答 14:7問目の解答
                  15:解いた問題番号
                  16:1問目があっているか　17:2問目があっているか　18:3問目があっているか　19:4問目があっているか
                  20:5問目があっているか　21:6問目があっているか　22:7問目があっているか

        */

    int player_data[]={0,
            0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,
            1,
            0,0,0,0,0,0,0
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

    }



    //スタート画面から画面を遷移させる
    public void onClickStart(View view) {
        switch (view.getId()){
            case R.id.start:
                //インテントの生成
                Intent intent = new Intent(this, MainActivity.class);

                //バンドルの生成
                Bundle bundle = new Bundle();
                Bundle bundle_count = new Bundle();


                //乱数の取得を取得して次の問題を決める
                Random random=new Random();
                int nestQuizNum=random.nextInt(7)+1;
                player_data[0]=nestQuizNum;


                //バンドルにプレイヤーデータを渡す。
                bundle.putIntArray("PlayerData",player_data);

                //カウントダンを始めるデータを渡す。
                bundle_count.putInt("Count",30000);

                //インテントにバンドルを持たせる
                intent.putExtras(bundle);
                intent.putExtras(bundle_count);

                //別アクティビティへ移動
                startActivity(intent);
                break;
        }
    }
}
